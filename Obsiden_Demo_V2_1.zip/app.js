(function(){
  const $ = id => document.getElementById(id);
  const brl = n => n.toLocaleString('en-US',{style:'currency',currency:'USD'});
  const C = CONFIG;
  const K_SACOLA = 'sacola:' + C.slug, K_PEDIDOS = 'pedidos:' + C.slug;
  const norm = s => (s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
  const SVG={
    menu:'<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
    tag:'<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/>',
    receipt:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
    info:'<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
    star:'<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
    pin:'<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
    delivery:'<rect x="1" y="3" width="15" height="13" rx="1"/><path d="M16 8h4l3 3v5h-7z"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/>',
    store:'<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/>',
    burger:'<path d="M4 10a8 6 0 0 1 16 0z"/><line x1="3" y1="14" x2="21" y2="14"/><path d="M4 17h16a4 3 0 0 1-16 0z"/>',
    drink:'<path d="M6 3h12l-1.5 18h-9z"/><line x1="12" y1="3" x2="15" y2="1"/><line x1="7" y1="9" x2="17" y2="9"/>',
    fries:'<path d="M6 10h12l-1.5 11h-9z"/><path d="M8 10V4M11 10V3M14 10V4M17 10V5"/>',
    dessert:'<path d="M3 21h18"/><path d="M5 21v-9a7 7 0 0 1 14 0v9"/><path d="M12 5V2"/>',
    pizza:'<path d="M12 2L3 20h18z"/><circle cx="12" cy="11" r="1"/><circle cx="9" cy="16" r="1"/><circle cx="15" cy="16" r="1"/>',
    bowl:'<path d="M3 11h18a9 9 0 0 1-18 0z"/><path d="M8 6c1-2 3-2 4 0M13 6c1-2 3-2 4 0"/>'
  };
  const ic=(n,cls)=>'<span class="ic'+(cls?' '+cls:'')+'"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+SVG[n]+'</svg></span>';
  document.querySelectorAll('[data-ic]').forEach(el=>{ el.outerHTML=ic(el.dataset.ic); });
  const esc = s => String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

  // ---------- horário ----------
  const DIAS=['sun','mon','tue','wed','thu','fri','sat'], DIAS_NOME=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
  const min=h=>{const [a,b]=h.split(':').map(Number);return a*60+b;};
  function situacao(agora){
    if(!C.horario) return {aberto:true};
    const d=agora.getDay(), m=agora.getHours()*60+agora.getMinutes();
    const hoje=C.horario[DIAS[d]];
    if(hoje){const [a,f]=hoje.map(min); if(hoje[0]==='00:00'&&hoje[1]==='23:59') return {aberto:true,h24:true}; if(f>a?(m>=a&&m<f):(m>=a)) return {aberto:true,fecha:hoje[1]};}
    const ontem=C.horario[DIAS[(d+6)%7]];
    if(ontem){const [a,f]=ontem.map(min); if(f<=a&&m<f) return {aberto:true,fecha:ontem[1]};}
    for(let i=0;i<7;i++){const dd=(d+i)%7,h=C.horario[DIAS[dd]]; if(!h) continue; if(i===0&&m>=min(h[0])) continue;
      return {aberto:false,abre:(i===0?'today':i===1?'tomorrow':DIAS_NOME[dd])+' at '+h[0]};}
    return {aberto:false};
  }
  const sit=situacao(new Date());

  // ---------- cabeçalho ----------
  $('topoNome').textContent=C.nome; $('nome').textContent=C.nome; document.title=C.nome+' – Menu';
  if(C.capa){$('capa').innerHTML='<img src="'+esc(C.capa)+'" alt="">';} else {$('capa').style.background='linear-gradient(135deg,'+C.cor+',#222)';}
  if(C.avaliacao){$('capa').insertAdjacentHTML('beforeend','<div class="nota">★ '+String(C.avaliacao).replace('.',',')+'</div>');}
  if(C.logo){$('logo').innerHTML='<img src="'+esc(C.logo)+'" alt="">';} else {$('logo').textContent=C.nome.split(/\s+/).map(w=>w[0]).join('').slice(0,2).toUpperCase();}
  const st=$('status'); st.className='status'+(sit.aberto?'':' fechado');
  let stHtml='<span class="dot"></span>'+(sit.aberto?('Open'+(sit.h24?' • 24h':sit.fecha?' until '+sit.fecha:' now')):('Closed'+(sit.abre?', opens '+sit.abre:'')));
  const local=[C.bairro,C.cidade].filter(Boolean).join(', ');
  if(local) stHtml+='<span class="sep">•</span><span style="font-weight:500;color:var(--muted)">'+ic('pin')+esc(local)+'</span>';
  stHtml+='<span class="sep">•</span><a id="maisInfo">More info</a>';
  st.innerHTML=stHtml; $('maisInfo').onclick=()=>abrirInfo();
  const modos=[]; if(C.entrega) modos.push('<span>'+ic('delivery')+'Delivery <small>'+(C.tempo_entrega?esc(C.tempo_entrega)+' • ':'')+(C.taxa_entrega>0?brl(C.taxa_entrega):'Free')+'</small></span>');
  if(C.retirada) modos.push('<span>'+ic('store')+'Pickup</span>'); if(C.pedido_minimo>0) modos.push('<span><small>Minimum '+brl(C.pedido_minimo)+'</small></span>');
  $('modos').innerHTML=modos.join(''); if(!modos.length) $('modos').style.display='none';
  $('boas').textContent=C.boas_vindas||C.descricao||''; if(!$('boas').textContent) $('boas').style.display='none';
  $('rodape').innerHTML=(C.marca?'Powered by <b>'+esc(C.marca)+'</b> • ':'')+'Order sent directly to the restaurant • no marketplace fees';

  // ---------- itens ----------
  const itens={}; const lista=[];
  const icone=cat=>{const c=norm(cat); const n=/bebida|suco|drink|refri/.test(c)?'drink':/sobremesa|doce/.test(c)?'dessert':/batata|acompanh|porc/.test(c)?'fries':/pizza/.test(c)?'pizza':/acai|salada|marmita|prato|almoc/.test(c)?'bowl':'burger'; return ic(n);};
  C.cardapio.forEach((cat,ci)=>cat.itens.forEach((it,ii)=>{const key=ci+'-'+ii; itens[key]=Object.assign({key,cat:cat.categoria},it); lista.push(itens[key]);}));
  const porNome=n=>lista.find(i=>norm(i.nome)===norm(n));
  const sugestoes=(C.sugestoes||[]).map(porNome).filter(Boolean);

  function card(it,extra){
    const promo=it.de&&it.de>it.preco;
    return '<button class="card" data-key="'+it.key+'" data-busca="'+esc(norm(it.nome+' '+(it.desc||'')+' '+it.cat))+'">'+
      (it.imagem?'<img class="foto'+(it.ajuste==='contain'?' contain':'')+'" src="'+esc(it.imagem)+'" alt="" loading="lazy">':'<div class="semfoto">'+icone(it.cat)+'</div>')+
      (promo?'<span class="tag promo">Special</span>':it.badge?'<span class="tag">'+esc(it.badge)+'</span>':'')+
      '<span class="qtd" hidden></span>'+
      '<div class="txt"><div class="n">'+esc(it.nome)+'</div>'+(it.desc?'<div class="d">'+esc(it.desc)+'</div>':'')+
      '<div class="p">'+brl(it.preco)+(promo?'<s>'+brl(it.de)+'</s>':'')+'</div></div><span class="mais">+</span></button>';
  }
  const menu=$('menu'); let html='';
  const destaques=lista.filter(i=>i.destaque);
  if(destaques.length) html+='<section id="destaques"><h2>'+ic('star')+'Destaques</h2><div class="scroller">'+destaques.map(card).join('')+'</div></section>';
  const promos=lista.filter(i=>i.de&&i.de>i.preco);
  if(promos.length) html+='<section id="promocoes"><h2>'+ic('tag')+'Specials</h2><div class="grade">'+promos.map(card).join('')+'</div></section>';
  C.cardapio.forEach((cat,ci)=>{ html+='<section id="cat'+ci+'" class="categoria"><h2>'+esc(cat.categoria)+'</h2><div class="grade">'+cat.itens.map((_,ii)=>card(itens[ci+'-'+ii])).join('')+'</div></section>'; });
  menu.innerHTML=html;
  menu.querySelectorAll('.card').forEach(el=>el.onclick=()=>abrirItem(el.dataset.key));
  const sel=$('selCat'); sel.innerHTML='<option value="">Browse categories</option>'+C.cardapio.map((c,i)=>'<option value="cat'+i+'">'+esc(c.categoria)+'</option>').join('');
  sel.onchange=()=>{ if(sel.value){ $(sel.value).scrollIntoView({behavior:'smooth',block:'start'}); } };
  $('busca').oninput=()=>{
    const q=norm($('busca').value.trim());
    menu.querySelectorAll('section').forEach(sec=>{
      if(!sec.classList.contains('categoria')){ sec.style.display=q?'none':''; return; }
      let vis=0; sec.querySelectorAll('.card').forEach(c=>{const ok=!q||c.dataset.busca.includes(q); c.style.display=ok?'':'none'; if(ok) vis++;});
      sec.style.display=vis?'':'none';
    });
  };

  // ---------- sacola ----------
  let sacola=[]; try{ sacola=JSON.parse(localStorage.getItem(K_SACOLA)||'[]'); }catch(e){}
  const salvar=()=>{ try{ localStorage.setItem(K_SACOLA,JSON.stringify(sacola)); }catch(e){} };
  const subtotal=()=>sacola.reduce((s,l)=>s+l.preco*l.qtd,0);
  const nItens=()=>sacola.reduce((s,l)=>s+l.qtd,0);
  function toast(t){ const el=$('toast'); el.textContent=t; el.classList.add('show'); clearTimeout(el._t); el._t=setTimeout(()=>el.classList.remove('show'),1400); }
  function addSacola(key,qtd,obs){
    const it=itens[key]; obs=obs||'';
    const ex=sacola.find(l=>l.key===key&&l.obs===obs);
    if(ex) ex.qtd+=qtd; else sacola.push({key,nome:it.nome,preco:it.preco,qtd,obs,imagem:it.imagem||''});
    salvar(); renderSacola(); toast('Added to cart');
  }
  function linhaHtml(l,i){
    return '<div class="cart-item">'+(l.imagem?'<img src="'+esc(l.imagem)+'" alt="">':'')+'<div class="txt"><div class="nome">'+esc(l.nome)+'</div>'+(l.obs?'<div class="obs">'+esc(l.obs)+'</div>':'')+'<div class="obs">'+brl(l.preco*l.qtd)+'</div></div><div class="mini"><button data-i="'+i+'" data-d="-1">−</button><b>'+l.qtd+'</b><button data-i="'+i+'" data-d="1">+</button></div></div>';
  }
  function chipsHtml(){
    const fora=sugestoes.filter(s=>!sacola.some(l=>l.key===s.key));
    if(!fora.length) return '';
    return '<label class="campo">You may also like</label><div class="chips">'+fora.map(s=>'<button class="chip" data-key="'+s.key+'">'+(s.imagem?'<img src="'+esc(s.imagem)+'" alt="">':'<span class="semfoto">'+icone(s.cat)+'</span>')+'<span>'+esc(s.nome)+'<small>'+brl(s.preco)+'</small></span></button>').join('')+'</div>';
  }
  function renderSacola(){
    const n=nItens(), sub=subtotal();
    $('barra').classList.toggle('show',n>0); $('barraQtd').textContent=n; $('barraTotal').textContent=brl(sub);
    menu.querySelectorAll('.card').forEach(el=>{const q=sacola.filter(l=>l.key===el.dataset.key).reduce((s,l)=>s+l.qtd,0); const b=el.querySelector('.qtd'); b.hidden=!q; b.textContent=q+'x';});
    const listaHtml=sacola.length?sacola.map(linhaHtml).join(''):'<div class="vazio">Your cart is empty</div>';
    ['sacolaLista','asideLista'].forEach(id=>{$(id).innerHTML=listaHtml;});
    ['sacolaSugestoes','asideSugestoes'].forEach(id=>{$(id).innerHTML=chipsHtml();});
    $('sacolaSub').textContent=brl(sub); $('sacolaTotal').textContent=brl(sub); $('asideSub').textContent=brl(sub); $('asideTotal').textContent=brl(sub);
    $('irCheckout').disabled=!sacola.length; $('asideFinalizar').disabled=!sacola.length;
    document.querySelectorAll('.cart-item button').forEach(b=>b.onclick=()=>{const i=+b.dataset.i; sacola[i].qtd+=+b.dataset.d; if(sacola[i].qtd<=0) sacola.splice(i,1); salvar(); renderSacola();});
    document.querySelectorAll('.chip').forEach(b=>b.onclick=()=>addSacola(b.dataset.key,1,''));
  }

  // ---------- sheets ----------
  const sheets=['sheetItem','sheetSacola','sheetCheckout','sheetInfo','sheetPedidos'];
  function abrir(id){ sheets.forEach(s=>$(s).classList.toggle('show',s===id)); $('veu').classList.add('show'); document.body.style.overflow='hidden'; $(id).scrollTop=0; }
  function fechar(){ sheets.forEach(s=>$(s).classList.remove('show')); $('veu').classList.remove('show'); document.body.style.overflow=''; setNav('cardapio'); }
  $('veu').onclick=fechar;

  // item
  let atual=null, qtd=1;
  function abrirItem(key){
    atual=key; qtd=1; const it=itens[key];
    const f=$('siFoto'); if(it.imagem){f.src=it.imagem; f.hidden=false; f.classList.toggle('contain',it.ajuste==='contain');} else {f.hidden=true; f.removeAttribute('src');}
    $('siNome').textContent=it.nome; $('siDesc').textContent=it.desc||''; $('siObs').value='';
    $('siPreco').innerHTML=brl(it.preco)+(it.de&&it.de>it.preco?' <s style="color:var(--muted);font-weight:500;font-size:14px">'+brl(it.de)+'</s>':'');
    const sug=sugestoes.filter(s=>s.key!==key);
    $('siSugBox').style.display=sug.length?'':'none';
    $('siSug').innerHTML=sug.map(s=>'<button class="chip" data-key="'+s.key+'">'+(s.imagem?'<img src="'+esc(s.imagem)+'" alt="">':'<span class="semfoto">'+icone(s.cat)+'</span>')+'<span>'+esc(s.nome)+'<small>+ '+brl(s.preco)+'</small></span></button>').join('');
    $('siSug').querySelectorAll('.chip').forEach(b=>b.onclick=()=>{addSacola(b.dataset.key,1,''); b.style.opacity=.4;});
    renderItem(); abrir('sheetItem');
    if(window.fbq) fbq('track','ViewContent',{content_name:it.nome,value:it.preco,currency:'USD'});
  }
  function renderItem(){ $('siQtd').textContent=qtd; $('siTotal').textContent=brl(itens[atual].preco*qtd); }
  $('siMenos').onclick=()=>{ if(qtd>1){qtd--;renderItem();} };
  $('siMais').onclick=()=>{ qtd++; renderItem(); };
  $('siAdd').onclick=()=>{ addSacola(atual,qtd,$('siObs').value.trim()); fechar(); };

  // sacola / checkout
  $('verSacola').onclick=()=>{ renderSacola(); abrir('sheetSacola'); };
  $('addMais').onclick=fechar;
  let tipo=C.entrega?'delivery':'pickup';
  const tipos=[]; if(C.entrega) tipos.push(['delivery',ic('delivery')+'Delivery']); if(C.retirada) tipos.push(['pickup',ic('store')+'Pickup']);
  tipos.forEach(([v,t])=>{const b=document.createElement('button'); b.innerHTML=t; b.dataset.v=v; b.onclick=()=>{tipo=v;renderCheckout();}; $('ckTipo').appendChild(b);});
  if(tipos.length<2){ $('ckTipo').style.display='none'; $('lblTipo').style.display='none'; }
  (C.pagamentos||['Card']).forEach(p=>{const o=document.createElement('option'); o.textContent=p; $('ckPag').appendChild(o);});
  $('ckPag').onchange=renderCheckout;
  const taxa=()=>tipo==='delivery'?(C.taxa_entrega||0):0;
  function renderCheckout(){
    [...$('ckTipo').children].forEach(b=>b.classList.toggle('on',b.dataset.v===tipo));
    $('boxEndereco').style.display=tipo==='delivery'?'':'none';
    $('boxTroco').style.display=/cash/i.test($('ckPag').value)?'':'none';
    $('boxPix').style.display='none';
    $('linhaTaxa').style.display=tipo==='delivery'?'':'none';
    $('ckSub').textContent=brl(subtotal()); $('ckTaxa').textContent=taxa()>0?brl(taxa()):'Free'; $('ckTotal').textContent=brl(subtotal()+taxa());
    const av=$('ckAviso'), s=situacao(new Date());
    if(!s.aberto&&!C.aceitar_fechado){ av.style.display=''; av.textContent='We are closed right now.'+(s.abre?' Abrimos '+s.abre+'.':''); $('enviar').disabled=true; }
    else { av.style.display='none'; $('enviar').disabled=false; }
  }
  const irCheckout=()=>{ if(!sacola.length) return; renderCheckout(); abrir('sheetCheckout'); if(window.fbq) fbq('track','InitiateCheckout',{value:subtotal(),currency:'USD',num_items:nItens()}); };
  $('irCheckout').onclick=irCheckout; $('asideFinalizar').onclick=irCheckout;
  function erro(t){ const e=$('ckErro'); e.textContent=t; e.style.display=t?'':'none'; }
  $('enviar').onclick=()=>{
    erro('');
    const nome=$('ckNome').value.trim(), end=$('ckEnd').value.trim(), pag=$('ckPag').value, troco=$('ckTroco').value.trim(), obs=$('ckObs').value.trim();
    if(!nome) return erro('Enter your name.');
    if(tipo==='delivery'&&!end) return erro('Enter your delivery address.');
    if(C.pedido_minimo&&subtotal()<C.pedido_minimo) return erro('Minimum order is '+brl(C.pedido_minimo)+'.');
    const num=Math.random().toString(36).slice(2,6).toUpperCase(), agora=new Date();
    const L=['*NEW ORDER – '+C.nome+'*','Order #'+num+' • '+agora.toLocaleDateString('en-US')+' '+agora.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'}),'','*Itens*'];
    sacola.forEach(l=>{L.push(l.qtd+'x '+l.nome+' – '+brl(l.preco*l.qtd)); if(l.obs) L.push('   Note: '+l.obs);});
    L.push('','Subtotal: '+brl(subtotal())); if(tipo==='delivery') L.push('Delivery: '+(taxa()>0?brl(taxa()):'Free'));
    L.push('*Total: '+brl(subtotal()+taxa())+'*','',tipo==='delivery'?'*Delivery address:* '+end:'*Pickup:* At the counter','*Payment:* '+pag+(troco?' (change for $'+troco+')':''),'*Customer:* '+nome);
    if(obs) L.push('*Note:* '+obs);
    const url='https://wa.me/'+C.whatsapp.replace(/\D/g,'')+'?text='+encodeURIComponent(L.join('\n'));
    try{ const h=JSON.parse(localStorage.getItem(K_PEDIDOS)||'[]'); h.unshift({num,data:agora.toISOString(),tipo,total:subtotal()+taxa(),itens:sacola.map(l=>({key:l.key,nome:l.nome,qtd:l.qtd,obs:l.obs}))}); localStorage.setItem(K_PEDIDOS,JSON.stringify(h.slice(0,20))); }catch(e){}
    if(window.fbq){ fbq('track','Contact',{value:subtotal()+taxa(),currency:'USD'}); fbq('trackCustom','TestOrder',{value:subtotal()+taxa(),currency:'USD',itens:sacola.length}); }
    sacola=[]; salvar(); renderSacola(); fechar(); toast('Opening order…');
    setTimeout(()=>{ window.location.href=url; },350);
  };

  // info
  function abrirInfo(){
    const h=[];
    if(C.endereco||local) h.push('<div class="info-l"><b>Address</b><span>'+esc([C.endereco,local].filter(Boolean).join(' – '))+'</span></div>');
    if(C.horario){ h.push('<div class="info-l"><b>Hours</b><table>'+DIAS.map((d,i)=>'<tr><td>'+DIAS_NOME[i][0].toUpperCase()+DIAS_NOME[i].slice(1)+'</td><td>'+(C.horario[d]?C.horario[d].join(' – '):'Closed')+'</td></tr>').join('')+'</table></div>'); }
    if(C.entrega) h.push('<div class="info-l"><b>Delivery</b><span>'+(C.tempo_entrega?esc(C.tempo_entrega)+' • ':'')+'fee '+(C.taxa_entrega>0?brl(C.taxa_entrega):'Free')+(C.pedido_minimo?' • minimum '+brl(C.pedido_minimo):'')+'</span></div>');
    if(C.pagamentos) h.push('<div class="info-l"><b>Payment</b><span>'+esc(C.pagamentos.join(', '))+'</span></div>');
    h.push('<div class="info-l"><b>Contact</b><a href="https://wa.me/'+C.whatsapp.replace(/\D/g,'')+'" target="_blank" rel="noopener" style="color:var(--cor);font-weight:600">Contact restaurant</a></div>');
    if(C.instagram) h.push('<div class="info-l"><b>Instagram</b><a href="https://instagram.com/'+esc(C.instagram.replace('@',''))+'" target="_blank" rel="noopener" style="color:var(--cor);font-weight:600">'+esc(C.instagram)+'</a></div>');
    $('infoBox').innerHTML=h.join(''); abrir('sheetInfo'); setNav('info');
  }
  // pedidos
  function abrirPedidos(){
    let h=[]; try{ h=JSON.parse(localStorage.getItem(K_PEDIDOS)||'[]'); }catch(e){}
    $('pedidosBox').innerHTML=h.length?h.map((p,i)=>'<div class="pedido-h"><div class="t"><span>Pedido #'+esc(p.num)+'</span><span>'+brl(p.total)+'</span></div><div class="i">'+new Date(p.data).toLocaleString('en-US',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})+' • '+(p.tipo==='delivery'?'Delivery':'Pickup')+'</div><div class="i">'+p.itens.map(x=>x.qtd+'x '+esc(x.nome)).join(', ')+'</div><button data-i="'+i+'">Order again</button></div>').join(''):'<div class="vazio">No orders yet</div>';
    $('pedidosBox').querySelectorAll('button').forEach(b=>b.onclick=()=>{ const p=h[+b.dataset.i]; p.itens.forEach(x=>{ if(itens[x.key]) addSacola(x.key,x.qtd,x.obs||''); }); fechar(); toast('Items added to cart'); });
    abrir('sheetPedidos'); setNav('pedidos');
  }
  // navegação
  function setNav(n){ document.querySelectorAll('[data-nav]').forEach(b=>b.classList.toggle('on',b.dataset.nav===n)); }
  document.querySelectorAll('[data-nav]').forEach(b=>b.onclick=()=>{
    const n=b.dataset.nav;
    if(n==='cardapio'){ fechar(); window.scrollTo({top:0,behavior:'smooth'}); }
    else if(n==='promocoes'){ fechar(); const s=$('promocoes'); if(s){ s.scrollIntoView({behavior:'smooth',block:'start'}); setNav('promocoes'); } else toast('No specials today'); }
    else if(n==='pedidos') abrirPedidos();
    else if(n==='info') abrirInfo();
  });

  renderSacola();
})();
